const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  // App info
  getVersion: () => ipcRenderer.invoke('get-version'),
  platform: process.platform,

  // File dialogs
  saveFile: (options) => ipcRenderer.invoke('save-file', options),
  openFile: (filters) => ipcRenderer.invoke('open-file', filters),

  // Open browser links
  openExternal: (url) => ipcRenderer.invoke('open-external', url),

  // Check if running in Electron
  isElectron: true,
});
