const { app, BrowserWindow, Menu, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const isDev = process.env.NODE_ENV === 'development';

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1366,
    height: 840,
    minWidth: 1024,
    minHeight: 680,
    title: 'Predictor Safari Club CRM',
    icon: path.join(__dirname, 'icon.ico'),
    backgroundColor: '#F4F6F4',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
    },
    show: false, // show after ready
  });

  // Load app
  if (isDev) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools();
  } else {
    mainWindow.loadFile(path.join(__dirname, '../frontend/dist/index.html'));
  }

  // Show when ready to prevent white flash
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  // Remove default menu in production
  if (!isDev) {
    Menu.setApplicationMenu(null);
  }
}

// IPC Handlers
ipcMain.handle('get-version', () => app.getVersion());

ipcMain.handle('save-file', async (event, { data, filename, filters }) => {
  const { filePath } = await dialog.showSaveDialog(mainWindow, {
    defaultPath: filename || 'export.pdf',
    filters: filters || [{ name: 'PDF', extensions: ['pdf'] }],
  });
  if (!filePath) return { success: false };
  const fs = require('fs');
  fs.writeFileSync(filePath, Buffer.from(data));
  return { success: true, filePath };
});

ipcMain.handle('open-file', async (event, filters) => {
  const { filePaths } = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: filters || [{ name: 'Documents', extensions: ['pdf', 'jpg', 'jpeg', 'png'] }],
  });
  if (!filePaths.length) return null;
  const fs = require('fs');
  const data = fs.readFileSync(filePaths[0]);
  return { path: filePaths[0], data: data.toString('base64'), name: path.basename(filePaths[0]) };
});

ipcMain.handle('open-external', async (event, url) => {
  await shell.openExternal(url);
});

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
