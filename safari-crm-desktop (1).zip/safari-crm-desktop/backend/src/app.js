require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const path    = require('path');

const app = express();

// ── Middleware ─────────────────────────────────────────────────
app.use(cors({ origin: ['http://localhost:5173', 'file://'] }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, '../uploads')));

// ── Routes ─────────────────────────────────────────────────────
app.use('/api/auth',       require('./routes/auth'));
app.use('/api/bookings',   require('./routes/bookings'));
app.use('/api/customers',  require('./routes/customers'));
app.use('/api/packages',   require('./routes/packages'));
app.use('/api/quotations', require('./routes/quotations'));
app.use('/api/invoices',   require('./routes/invoices'));
app.use('/api/vehicles',   require('./routes/vehicles'));
app.use('/api/staff',      require('./routes/staff'));
app.use('/api/expenses',   require('./routes/expenses'));
app.use('/api/reports',    require('./routes/reports'));

// ── Health check ───────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', version: '1.0.0', company: process.env.COMPANY_NAME });
});

// ── Error handler ──────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({
    message: err.message || 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

// ── Start ──────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🦁 Safari CRM API running on http://localhost:${PORT}`);
  console.log(`   Company: ${process.env.COMPANY_NAME || 'Safari Club'}`);
  console.log(`   Env: ${process.env.NODE_ENV || 'development'}\n`);
});

module.exports = app;
