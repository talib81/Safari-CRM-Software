const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

let quotes = [
  { id: 1, quote_ref: 'QT-0041', customer_name: 'John Smith',    total: 4956,  currency: 'USD', status: 'accepted', valid_until: '2025-06-01' },
  { id: 2, quote_ref: 'QT-0040', customer_name: 'Amina Müller',  total: 3366,  currency: 'USD', status: 'sent',     valid_until: '2025-05-28' },
  { id: 3, quote_ref: 'QT-0039', customer_name: 'Chen Wei',      total: 2338,  currency: 'USD', status: 'draft',    valid_until: '2025-06-05' },
];

router.get('/',    auth, (req, res) => res.json(quotes));
router.get('/:id', auth, (req, res) => { const q = quotes.find(q => q.id === +req.params.id); q ? res.json(q) : res.status(404).json({ message: 'Not found' }); });
router.post('/',   auth, (req, res) => {
  const ref = `QT-${String(quotes.length + 42).padStart(4, '0')}`;
  const sub = req.body.subtotal || 0;
  const margin = sub * ((req.body.margin_percent || 20) / 100);
  const vat = (sub + margin) * 0.18;
  const q = { id: quotes.length + 1, quote_ref: ref, ...req.body, margin_amount: margin, vat_amount: vat, total: sub + margin + vat, status: 'draft', created_at: new Date() };
  quotes.push(q); res.status(201).json(q);
});
router.put('/:id', auth, (req, res) => { const i = quotes.findIndex(q => q.id === +req.params.id); if (i < 0) return res.status(404).json({ message: 'Not found' }); quotes[i] = { ...quotes[i], ...req.body }; res.json(quotes[i]); });
// PDF endpoint stub
router.get('/:id/pdf', auth, (req, res) => res.status(501).json({ message: 'PDF generation requires Puppeteer setup' }));
router.post('/:id/send', auth, (req, res) => res.json({ message: `Quote sent via ${req.body.method || 'email'}` }));
module.exports = router;
