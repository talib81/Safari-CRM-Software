const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

const packages = [
  { id: 1, name: '6-Day Serengeti Classic',       duration_days: 6,  base_price_usd: 3800, accommodation_type: 'luxury',   is_active: true },
  { id: 2, name: '4-Day Ngorongoro & Lake Manyara',duration_days: 4,  base_price_usd: 2200, accommodation_type: 'midrange', is_active: true },
  { id: 3, name: '3-Day Tarangire Explorer',       duration_days: 3,  base_price_usd: 1500, accommodation_type: 'camping',  is_active: true },
  { id: 4, name: '10-Day Northern Circuit',        duration_days: 10, base_price_usd: 7200, accommodation_type: 'luxury',   is_active: true },
];

router.get('/',    auth, (req, res) => res.json(packages));
router.get('/:id', auth, (req, res) => { const p = packages.find(p => p.id === +req.params.id); p ? res.json(p) : res.status(404).json({ message: 'Not found' }); });
module.exports = router;
