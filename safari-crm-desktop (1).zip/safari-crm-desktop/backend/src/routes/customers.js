const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

let customers = [
  { id: 1, full_name: 'John Smith',    nationality: 'United Kingdom', email: 'john@example.com',  phone: '+44 7911 111111', passport_number: 'AB123456' },
  { id: 2, full_name: 'Amina Müller',  nationality: 'Germany',        email: 'amina@example.com', phone: '+49 151 2222222', passport_number: 'DE789012' },
  { id: 3, full_name: 'Chen Wei',      nationality: 'China',          email: 'chen@example.com',  phone: '+86 131 3333333', passport_number: 'CN345678' },
];

router.get('/',        auth, (req, res) => res.json(customers));
router.get('/search',  auth, (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  res.json(customers.filter(c => c.full_name.toLowerCase().includes(q) || c.email.toLowerCase().includes(q)));
});
router.get('/:id',    auth, (req, res) => { const c = customers.find(c => c.id === +req.params.id); c ? res.json(c) : res.status(404).json({ message: 'Not found' }); });
router.post('/',      auth, (req, res) => { const c = { id: customers.length + 1, ...req.body, created_at: new Date() }; customers.push(c); res.status(201).json(c); });
router.put('/:id',    auth, (req, res) => { const i = customers.findIndex(c => c.id === +req.params.id); if (i < 0) return res.status(404).json({ message: 'Not found' }); customers[i] = { ...customers[i], ...req.body }; res.json(customers[i]); });
module.exports = router;
