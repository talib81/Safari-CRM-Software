// routes/reports.js
const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

router.get('/dashboard', auth, (req, res) => {
  res.json({
    bookings_this_month: 24, revenue_usd: 38400,
    outstanding_invoices: 7, vehicles_on_safari: 5,
    vehicles_total: 8, revenue_growth: 18, bookings_growth: 12,
  });
});

router.get('/revenue', auth, (req, res) => {
  res.json([
    { month: 'Jan', usd: 22000 }, { month: 'Feb', usd: 18000 },
    { month: 'Mar', usd: 31000 }, { month: 'Apr', usd: 26000 },
    { month: 'May', usd: 38400 }, { month: 'Jun', usd: 29000 },
  ]);
});

router.get('/bookings', auth, (req, res) => {
  res.json({ total: 24, confirmed: 18, pending: 4, cancelled: 2 });
});

router.get('/vehicles', auth, (req, res) => {
  res.json({ total: 8, on_safari: 5, available: 2, maintenance: 1 });
});

module.exports = router;
