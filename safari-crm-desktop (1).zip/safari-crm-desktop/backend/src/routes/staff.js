const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

let staff = [
  { id: 1, full_name: 'Joseph Mwangi',  role: 'guide',      phone: '+255 712 111 222', hire_date: '2017-03-01', salary_tzs: 800000,  status: 'active' },
  { id: 2, full_name: 'Amina Njoroge',  role: 'guide',      phone: '+255 712 333 444', hire_date: '2021-06-15', salary_tzs: 650000,  status: 'active' },
  { id: 3, full_name: 'David Kimani',   role: 'driver',     phone: '+255 712 555 666', hire_date: '2019-01-10', salary_tzs: 550000,  status: 'active' },
  { id: 4, full_name: 'Grace Masanja',  role: 'accountant', phone: '+255 712 777 888', hire_date: '2020-08-01', salary_tzs: 1200000, status: 'active' },
  { id: 5, full_name: 'Peter Oduya',    role: 'driver',     phone: '+255 712 999 000', hire_date: '2022-02-14', salary_tzs: 520000,  status: 'active' },
];

router.get('/',                auth, (req, res) => res.json(staff));
router.get('/:id',             auth, (req, res) => { const s = staff.find(s => s.id === +req.params.id); s ? res.json(s) : res.status(404).json({ message: 'Not found' }); });
router.post('/',               auth, (req, res) => { const s = { id: staff.length + 1, ...req.body, status: 'active', created_at: new Date() }; staff.push(s); res.status(201).json(s); });
router.put('/:id',             auth, (req, res) => { const i = staff.findIndex(s => s.id === +req.params.id); if (i < 0) return res.status(404).json({ message: 'Not found' }); staff[i] = { ...staff[i], ...req.body }; res.json(staff[i]); });
router.post('/:id/attendance', auth, (req, res) => res.json({ message: 'Attendance recorded', staff_id: req.params.id, ...req.body }));
module.exports = router;
