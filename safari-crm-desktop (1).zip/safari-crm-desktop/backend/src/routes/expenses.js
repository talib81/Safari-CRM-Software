const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

let expenses = [
  { id: 1, category: 'fuel',      description: 'Fuel for T 789 ABC',      amount_tzs: 280000,  expense_date: '2025-05-20', recorded_by_name: 'Admin' },
  { id: 2, category: 'salaries',  description: 'May 2025 guide salaries', amount_tzs: 3200000, expense_date: '2025-05-01', recorded_by_name: 'Grace Masanja' },
  { id: 3, category: 'repairs',   description: 'Engine check T 123 GHI',  amount_tzs: 450000,  expense_date: '2025-05-03', recorded_by_name: 'Admin' },
  { id: 4, category: 'office',    description: 'Office supplies',          amount_tzs: 85000,   expense_date: '2025-05-12', recorded_by_name: 'Admin' },
  { id: 5, category: 'marketing', description: 'TripAdvisor listing',      amount_tzs: 320000,  expense_date: '2025-05-15', recorded_by_name: 'Admin' },
];

router.get('/',          auth, (req, res) => res.json(expenses));
router.get('/summary',   auth, (req, res) => {
  const summary = {};
  expenses.forEach(e => { summary[e.category] = (summary[e.category] || 0) + e.amount_tzs; });
  res.json(summary);
});
router.post('/', auth, (req, res) => {
  const exp = { id: expenses.length + 1, ...req.body, recorded_by_name: 'Admin', created_at: new Date() };
  expenses.push(exp); res.status(201).json(exp);
});
module.exports = router;
