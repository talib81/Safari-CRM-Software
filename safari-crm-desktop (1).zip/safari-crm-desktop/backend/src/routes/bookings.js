const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

// Mock data — replace with Sequelize queries
let bookings = [
  { id: 1, booking_ref: 'SAF-0091', customer_id: 1, package_id: 1, customer_name: 'John Smith', package_name: '6-Day Serengeti', start_date: '2025-06-10', end_date: '2025-06-16', num_adults: 2, num_children: 0, status: 'confirmed', total: 4200, created_at: new Date() },
  { id: 2, booking_ref: 'SAF-0090', customer_id: 2, package_id: 2, customer_name: 'Amina Müller', package_name: 'Ngorongoro + Lake', start_date: '2025-06-05', end_date: '2025-06-09', num_adults: 3, num_children: 0, status: 'pending',   total: 2850, created_at: new Date() },
  { id: 3, booking_ref: 'SAF-0089', customer_id: 3, package_id: 3, customer_name: 'Chen Wei',    package_name: '3-Day Tarangire',  start_date: '2025-05-28', end_date: '2025-05-30', num_adults: 2, num_children: 0, status: 'confirmed', total: 1980, created_at: new Date() },
  { id: 4, booking_ref: 'SAF-0088', customer_id: 4, package_id: 4, customer_name: 'Sarah Okonkwo', package_name: '10-Day Circuit', start_date: '2025-07-01', end_date: '2025-07-11', num_adults: 4, num_children: 1, status: 'enquiry',   total: 8200, created_at: new Date() },
];

// GET /api/bookings
router.get('/', auth, (req, res) => {
  let result = [...bookings];
  const { status, limit, search } = req.query;
  if (status)  result = result.filter(b => b.status === status);
  if (search)  result = result.filter(b =>
    b.customer_name?.toLowerCase().includes(search.toLowerCase()) ||
    b.booking_ref?.toLowerCase().includes(search.toLowerCase())
  );
  if (limit)   result = result.slice(0, parseInt(limit));
  res.json({ bookings: result, total: result.length });
});

// GET /api/bookings/stats
router.get('/stats', auth, (req, res) => {
  res.json({
    bookings_this_month: 24,
    revenue_usd: 38400,
    outstanding_invoices: 7,
    vehicles_on_safari: 5,
    vehicles_total: 8,
    revenue_growth: 18,
    bookings_growth: 12,
  });
});

// GET /api/bookings/:id
router.get('/:id', auth, (req, res) => {
  const booking = bookings.find(b => b.id === parseInt(req.params.id));
  if (!booking) return res.status(404).json({ message: 'Booking not found' });
  res.json(booking);
});

// POST /api/bookings
router.post('/', auth, (req, res) => {
  const year = new Date().getFullYear();
  const ref  = `SAF-${year}-${String(bookings.length + 1).padStart(4, '0')}`;
  const newBooking = {
    id: bookings.length + 1,
    booking_ref: ref,
    ...req.body,
    status: 'enquiry',
    created_by: req.user.id,
    created_at: new Date(),
  };
  bookings.push(newBooking);
  res.status(201).json(newBooking);
});

// PUT /api/bookings/:id
router.put('/:id', auth, (req, res) => {
  const idx = bookings.findIndex(b => b.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ message: 'Booking not found' });
  bookings[idx] = { ...bookings[idx], ...req.body, updated_at: new Date() };
  res.json(bookings[idx]);
});

// DELETE /api/bookings/:id
router.delete('/:id', auth, (req, res) => {
  const idx = bookings.findIndex(b => b.id === parseInt(req.params.id));
  if (idx === -1) return res.status(404).json({ message: 'Booking not found' });
  bookings.splice(idx, 1);
  res.json({ message: 'Booking deleted' });
});

module.exports = router;
