const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

let invoices = [
  { id: 1, invoice_ref: 'INV-0031', customer_name: 'John Smith',   amount_due: 4956, amount_paid: 4956, currency: 'USD', status: 'paid',    due_date: '2025-05-30' },
  { id: 2, invoice_ref: 'INV-0030', customer_name: 'Amina Müller', amount_due: 3366, amount_paid: 1000, currency: 'USD', status: 'partial', due_date: '2025-06-05' },
  { id: 3, invoice_ref: 'INV-0029', customer_name: 'Chen Wei',     amount_due: 2338, amount_paid: 0,    currency: 'USD', status: 'unpaid',  due_date: '2025-06-10' },
  { id: 4, invoice_ref: 'INV-0028', customer_name: 'Hans Berger',  amount_due: 2832, amount_paid: 0,    currency: 'USD', status: 'overdue', due_date: '2025-05-01' },
];

router.get('/',    auth, (req, res) => res.json(invoices));
router.get('/:id', auth, (req, res) => { const inv = invoices.find(i => i.id === +req.params.id); inv ? res.json(inv) : res.status(404).json({ message: 'Not found' }); });
router.post('/',   auth, (req, res) => {
  const ref = `INV-${String(invoices.length + 32).padStart(4, '0')}`;
  const inv = { id: invoices.length + 1, invoice_ref: ref, ...req.body, amount_paid: 0, status: 'unpaid', created_at: new Date() };
  invoices.push(inv); res.status(201).json(inv);
});
router.post('/:id/payments', auth, (req, res) => {
  const i = invoices.findIndex(inv => inv.id === +req.params.id);
  if (i < 0) return res.status(404).json({ message: 'Not found' });
  invoices[i].amount_paid += req.body.amount || 0;
  invoices[i].status = invoices[i].amount_paid >= invoices[i].amount_due ? 'paid' : 'partial';
  res.json(invoices[i]);
});
module.exports = router;
