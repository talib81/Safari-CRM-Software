const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const router   = express.Router();
const auth     = require('../middleware/auth');

// Demo users (replace with DB query in production)
const DEMO_USERS = [
  { id: 1, name: 'Admin',          email: 'admin@safariclub.tz',      role: 'admin',      password: '$2a$10$rOzJqkZzL4b2cO5kOmXM6.g6XC3lUcJwQeYlkGnV7pI9pMg2iXKKa' }, // admin123
  { id: 2, name: 'Grace Masanja',  email: 'grace@safariclub.tz',       role: 'accountant', password: '$2a$10$rOzJqkZzL4b2cO5kOmXM6.g6XC3lUcJwQeYlkGnV7pI9pMg2iXKKa' },
  { id: 3, name: 'Joseph Mwangi', email: 'joseph@safariclub.tz',      role: 'staff',      password: '$2a$10$rOzJqkZzL4b2cO5kOmXM6.g6XC3lUcJwQeYlkGnV7pI9pMg2iXKKa' },
];

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: 'Email and password required' });

    const user = DEMO_USERS.find(u => u.email === email);
    if (!user) return res.status(401).json({ message: 'Invalid email or password' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ message: 'Invalid email or password' });

    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role, name: user.name },
      process.env.JWT_SECRET || 'safari_secret',
      { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
    );

    res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// GET /api/auth/me
router.get('/me', auth, (req, res) => {
  res.json({ user: req.user });
});

// POST /api/auth/logout
router.post('/logout', auth, (req, res) => {
  res.json({ message: 'Logged out' });
});

module.exports = router;
