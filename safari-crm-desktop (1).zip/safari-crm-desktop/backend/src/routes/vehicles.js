const express = require('express');
const router  = express.Router();
const auth    = require('../middleware/auth');

let vehicles = [
  { id: 1, registration: 'T 789 ABC', make: 'Toyota',    model: 'Land Cruiser',  year: 2021, seats: 8,  status: 'available'   },
  { id: 2, registration: 'T 456 DEF', make: 'Toyota',    model: 'Land Cruiser',  year: 2020, seats: 8,  status: 'on_safari'   },
  { id: 3, registration: 'T 123 GHI', make: 'Toyota',    model: 'Hiace Minibus', year: 2019, seats: 12, status: 'maintenance' },
  { id: 4, registration: 'T 321 JKL', make: 'Toyota',    model: 'Land Cruiser',  year: 2022, seats: 8,  status: 'available'   },
  { id: 5, registration: 'T 654 MNO', make: 'Land Rover',model: 'Defender',      year: 2023, seats: 5,  status: 'available'   },
];

router.get('/',            auth, (req, res) => res.json(vehicles));
router.get('/available',   auth, (req, res) => res.json(vehicles.filter(v => v.status === 'available')));
router.get('/:id',         auth, (req, res) => { const v = vehicles.find(v => v.id === +req.params.id); v ? res.json(v) : res.status(404).json({ message: 'Not found' }); });
router.post('/',           auth, (req, res) => { const v = { id: vehicles.length + 1, ...req.body, status: 'available' }; vehicles.push(v); res.status(201).json(v); });
router.put('/:id',         auth, (req, res) => { const i = vehicles.findIndex(v => v.id === +req.params.id); if (i < 0) return res.status(404).json({ message: 'Not found' }); vehicles[i] = { ...vehicles[i], ...req.body }; res.json(vehicles[i]); });
router.post('/:id/fuel',   auth, (req, res) => res.json({ message: 'Fuel log recorded', ...req.body }));
router.post('/:id/service',auth, (req, res) => res.json({ message: 'Service log recorded', ...req.body }));
module.exports = router;
