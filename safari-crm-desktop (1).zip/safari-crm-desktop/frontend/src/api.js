import axios from 'axios';

const API_BASE = 'http://localhost:3000/api';

const api = axios.create({
  baseURL: API_BASE,
  timeout: 10000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT token to every request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('safari_crm_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle auth errors globally
api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response?.status === 401) {
      localStorage.removeItem('safari_crm_token');
      window.location.reload();
    }
    return Promise.reject(err);
  }
);

// ── Auth ──────────────────────────────────────────────
export const authAPI = {
  login:  (email, password) => api.post('/auth/login', { email, password }),
  logout: () => api.post('/auth/logout'),
  me:     () => api.get('/auth/me'),
};

// ── Bookings ──────────────────────────────────────────
export const bookingsAPI = {
  getAll:    (params) => api.get('/bookings', { params }),
  getById:   (id)     => api.get(`/bookings/${id}`),
  create:    (data)   => api.post('/bookings', data),
  update:    (id, data) => api.put(`/bookings/${id}`, data),
  delete:    (id)     => api.delete(`/bookings/${id}`),
  getStats:  ()       => api.get('/bookings/stats'),
};

// ── Customers ─────────────────────────────────────────
export const customersAPI = {
  getAll:  (params) => api.get('/customers', { params }),
  getById: (id)     => api.get(`/customers/${id}`),
  create:  (data)   => api.post('/customers', data),
  update:  (id, data) => api.put(`/customers/${id}`, data),
  search:  (q)      => api.get('/customers/search', { params: { q } }),
};

// ── Quotations ────────────────────────────────────────
export const quotationsAPI = {
  getAll:      (params) => api.get('/quotations', { params }),
  getById:     (id)     => api.get(`/quotations/${id}`),
  create:      (data)   => api.post('/quotations', data),
  update:      (id, data) => api.put(`/quotations/${id}`, data),
  generatePDF: (id)     => api.get(`/quotations/${id}/pdf`, { responseType: 'arraybuffer' }),
  send:        (id, method) => api.post(`/quotations/${id}/send`, { method }),
};

// ── Invoices ──────────────────────────────────────────
export const invoicesAPI = {
  getAll:     (params) => api.get('/invoices', { params }),
  getById:    (id)     => api.get(`/invoices/${id}`),
  create:     (data)   => api.post('/invoices', data),
  recordPayment: (id, data) => api.post(`/invoices/${id}/payments`, data),
  generatePDF:   (id)  => api.get(`/invoices/${id}/pdf`, { responseType: 'arraybuffer' }),
};

// ── Vehicles ──────────────────────────────────────────
export const vehiclesAPI = {
  getAll:        () => api.get('/vehicles'),
  getAvailable:  (start, end) => api.get('/vehicles/available', { params: { start, end } }),
  getById:       (id) => api.get(`/vehicles/${id}`),
  create:        (data) => api.post('/vehicles', data),
  update:        (id, data) => api.put(`/vehicles/${id}`, data),
  logFuel:       (id, data) => api.post(`/vehicles/${id}/fuel`, data),
  logService:    (id, data) => api.post(`/vehicles/${id}/service`, data),
};

// ── Staff / HR ────────────────────────────────────────
export const staffAPI = {
  getAll:         () => api.get('/staff'),
  getById:        (id) => api.get(`/staff/${id}`),
  create:         (data) => api.post('/staff', data),
  update:         (id, data) => api.put(`/staff/${id}`, data),
  logAttendance:  (id, data) => api.post(`/staff/${id}/attendance`, data),
};

// ── Packages ──────────────────────────────────────────
export const packagesAPI = {
  getAll:  () => api.get('/packages'),
  getById: (id) => api.get(`/packages/${id}`),
  create:  (data) => api.post('/packages', data),
  update:  (id, data) => api.put(`/packages/${id}`, data),
};

// ── Expenses ──────────────────────────────────────────
export const expensesAPI = {
  getAll:  (params) => api.get('/expenses', { params }),
  create:  (data) => api.post('/expenses', data),
  getSummary: (month) => api.get('/expenses/summary', { params: { month } }),
};

// ── Reports ───────────────────────────────────────────
export const reportsAPI = {
  dashboard:    () => api.get('/reports/dashboard'),
  bookings:     (params) => api.get('/reports/bookings', { params }),
  revenue:      (params) => api.get('/reports/revenue', { params }),
  vehicles:     () => api.get('/reports/vehicles'),
};

export default api;
