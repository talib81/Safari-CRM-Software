import { useState, useEffect } from 'react';
import { staffAPI } from '../api';

const MOCK = [
  { id: 1, full_name: 'Joseph Mwangi', role: 'guide', phone: '+255 712 111 222', hire_date: '2017-03-01', salary_tzs: 800000, status: 'active', languages: 'EN, SW, FR' },
  { id: 2, full_name: 'Amina Njoroge', role: 'guide', phone: '+255 712 333 444', hire_date: '2021-06-15', salary_tzs: 650000, status: 'active', languages: 'EN, SW' },
  { id: 3, full_name: 'David Kimani', role: 'driver', phone: '+255 712 555 666', hire_date: '2019-01-10', salary_tzs: 550000, status: 'active', languages: 'SW' },
  { id: 4, full_name: 'Grace Masanja', role: 'accountant', phone: '+255 712 777 888', hire_date: '2020-08-01', salary_tzs: 1200000, status: 'active', languages: 'EN, SW' },
  { id: 5, full_name: 'Peter Oduya', role: 'driver', phone: '+255 712 999 000', hire_date: '2022-02-14', salary_tzs: 520000, status: 'active', languages: 'SW' },
];

const roleColors = {
  guide:      { bg: '#EFF6FF', color: '#2563EB' },
  driver:     { bg: '#F0FDF4', color: '#16A34A' },
  accountant: { bg: '#FEF9EE', color: '#D97706' },
  admin:      { bg: '#FAF5FF', color: '#7C3AED' },
  manager:    { bg: '#FFF1F2', color: '#BE123C' },
};

const avatarColors = ['#7C3AED', '#DB2777', '#0891B2', '#16A34A', '#D97706', '#DC2626', '#2563EB'];

export default function StaffPage() {
  const [staff, setStaff] = useState(MOCK);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    staffAPI.getAll().then(r => setStaff(r.data)).catch(() => {});
  }, []);

  const filtered = filter === 'all' ? staff : staff.filter(s => s.role === filter);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '16px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>HR & Staff</h1>
          <p style={{ fontSize: 13, color: 'var(--text-mid)', marginTop: 2 }}>{staff.filter(s => s.status === 'active').length} active employees</p>
        </div>
        <button style={{ background: 'var(--primary-dark)', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
          ＋ Add Staff
        </button>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '22px 28px' }}>
        {/* Role filters */}
        <div style={{ display: 'flex', gap: 8, marginBottom: 18 }}>
          {['all', 'guide', 'driver', 'accountant', 'admin', 'manager'].map(r => (
            <button key={r} onClick={() => setFilter(r)}
              style={{ padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: '1.5px solid', fontFamily: 'inherit', background: filter === r ? 'var(--primary-dark)' : 'var(--white)', color: filter === r ? '#fff' : 'var(--text-mid)', borderColor: filter === r ? 'var(--primary-dark)' : 'var(--border)' }}>
              {r === 'all' ? 'All' : r.charAt(0).toUpperCase() + r.slice(1)}
            </button>
          ))}
        </div>

        <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg)' }}>
                {['Employee', 'Role', 'Phone', 'Hire Date', 'Salary (TZS)', 'Status', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: 'var(--text-mid)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((s, i) => {
                const rc = roleColors[s.role] || roleColors.admin;
                const initials = s.full_name.split(' ').map(n => n[0]).join('').slice(0, 2);
                const color = avatarColors[i % avatarColors.length];
                return (
                  <tr key={s.id || i} style={{ borderBottom: '1px solid var(--border)' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#FAFBFA'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                        <div style={{ width: 34, height: 34, borderRadius: '50%', background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 12, fontWeight: 700, color: '#fff', flexShrink: 0 }}>{initials}</div>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 600 }}>{s.full_name}</div>
                          {s.languages && <div style={{ fontSize: 11, color: 'var(--text-mid)' }}>{s.languages}</div>}
                        </div>
                      </div>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ background: rc.bg, color: rc.color, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>
                        {s.role?.charAt(0).toUpperCase() + s.role?.slice(1)}
                      </span>
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: 13, color: 'var(--text-mid)' }}>{s.phone}</td>
                    <td style={{ padding: '12px 16px', fontSize: 12, color: 'var(--text-mid)' }}>
                      {s.hire_date ? new Date(s.hire_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                    </td>
                    <td style={{ padding: '12px 16px', fontSize: 13, fontWeight: 600 }}>
                      TZS {(s.salary_tzs || 0).toLocaleString()}
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <span style={{ background: 'var(--success-bg)', color: 'var(--success)', borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>Active</span>
                    </td>
                    <td style={{ padding: '12px 16px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--text-mid)' }}>Edit</button>
                        <button style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--primary)' }}>Attendance</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
