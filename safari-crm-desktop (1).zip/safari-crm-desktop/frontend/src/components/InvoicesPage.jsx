import { useState, useEffect } from 'react';
import { invoicesAPI } from '../api';

const MOCK = [
  { id: 1, invoice_ref: 'INV-0031', customer_name: 'John Smith', amount_due: 4956, amount_paid: 4956, currency: 'USD', status: 'paid', due_date: '2025-05-30' },
  { id: 2, invoice_ref: 'INV-0030', customer_name: 'Amina Müller', amount_due: 3366, amount_paid: 1000, currency: 'USD', status: 'partial', due_date: '2025-06-05' },
  { id: 3, invoice_ref: 'INV-0029', customer_name: 'Chen Wei', amount_due: 2338, amount_paid: 0, currency: 'USD', status: 'unpaid', due_date: '2025-06-10' },
  { id: 4, invoice_ref: 'INV-0028', customer_name: 'Hans Berger', amount_due: 2832, amount_paid: 0, currency: 'USD', status: 'overdue', due_date: '2025-05-01' },
];

const statusColors = {
  paid:    { bg: '#DCFCE7', color: '#16A34A' },
  partial: { bg: '#EFF6FF', color: '#2563EB' },
  unpaid:  { bg: '#F3F4F6', color: '#6B7280' },
  overdue: { bg: '#FEE2E2', color: '#DC2626' },
};

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState(MOCK);

  useEffect(() => {
    invoicesAPI.getAll().then(r => setInvoices(r.data)).catch(() => {});
  }, []);

  const totalDue  = invoices.reduce((s, i) => s + (i.amount_due - i.amount_paid), 0);
  const totalPaid = invoices.reduce((s, i) => s + i.amount_paid, 0);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '16px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Invoices</h1>
          <p style={{ fontSize: 13, color: 'var(--text-mid)', marginTop: 2 }}>{invoices.length} invoices</p>
        </div>
        <button style={{ background: 'var(--primary-dark)', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
          ＋ New Invoice
        </button>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '22px 28px' }}>
        {/* Summary cards */}
        <div style={{ display: 'flex', gap: 14, marginBottom: 20 }}>
          {[
            { label: 'Total Outstanding', value: `$${totalDue.toLocaleString()}`, color: 'var(--danger)', bg: 'var(--danger-bg)' },
            { label: 'Total Collected', value: `$${totalPaid.toLocaleString()}`, color: 'var(--success)', bg: 'var(--success-bg)' },
            { label: 'Overdue', value: invoices.filter(i => i.status === 'overdue').length, color: 'var(--danger)', bg: 'var(--danger-bg)' },
          ].map(card => (
            <div key={card.label} style={{ background: card.bg, borderRadius: 12, padding: '14px 18px', flex: 1 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: card.color, marginBottom: 4 }}>{card.label}</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: card.color }}>{card.value}</div>
            </div>
          ))}
        </div>

        <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg)' }}>
                {['Invoice Ref', 'Customer', 'Amount Due', 'Amount Paid', 'Balance', 'Due Date', 'Status', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: 'var(--text-mid)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv, i) => {
                const s = statusColors[inv.status] || statusColors.unpaid;
                const balance = inv.amount_due - inv.amount_paid;
                return (
                  <tr key={inv.id || i} style={{ borderBottom: '1px solid var(--border)' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#FAFBFA'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}>
                    <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--primary)', fontWeight: 600 }}>{inv.invoice_ref}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13 }}>{inv.customer_name}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 600 }}>${inv.amount_due?.toLocaleString()}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--success)' }}>${inv.amount_paid?.toLocaleString()}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 700, color: balance > 0 ? 'var(--danger)' : 'var(--success)' }}>
                      ${balance.toLocaleString()}
                    </td>
                    <td style={{ padding: '13px 16px', fontSize: 12, color: 'var(--text-mid)' }}>
                      {inv.due_date ? new Date(inv.due_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                    </td>
                    <td style={{ padding: '13px 16px' }}>
                      <span style={{ background: s.bg, color: s.color, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>
                        {inv.status?.charAt(0).toUpperCase() + inv.status?.slice(1)}
                      </span>
                    </td>
                    <td style={{ padding: '13px 16px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--primary)' }}>PDF</button>
                        <button style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--text-mid)' }}>Pay</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
