import { useState, useEffect } from 'react';
import { vehiclesAPI } from '../api';

const MOCK = [
  { id: 1, registration: 'T 789 ABC', make: 'Toyota', model: 'Land Cruiser', year: 2021, seats: 8, status: 'available', last_service: '2025-04-10', fuel_logs: [] },
  { id: 2, registration: 'T 456 DEF', make: 'Toyota', model: 'Land Cruiser', year: 2020, seats: 8, status: 'on_safari', last_service: '2025-03-22', fuel_logs: [] },
  { id: 3, registration: 'T 123 GHI', make: 'Toyota', model: 'Hiace Minibus', year: 2019, seats: 12, status: 'maintenance', last_service: '2025-05-01', fuel_logs: [] },
  { id: 4, registration: 'T 321 JKL', make: 'Toyota', model: 'Land Cruiser', year: 2022, seats: 8, status: 'available', last_service: '2025-04-28', fuel_logs: [] },
  { id: 5, registration: 'T 654 MNO', make: 'Land Rover', model: 'Defender', year: 2023, seats: 5, status: 'available', last_service: '2025-05-05', fuel_logs: [] },
];

const statusMap = {
  available:   { label: 'Available',   bg: '#DCFCE7', color: '#16A34A', dot: '#16A34A' },
  on_safari:   { label: 'On Safari',   bg: '#FEF3C7', color: '#D97706', dot: '#D97706' },
  maintenance: { label: 'Maintenance', bg: '#FEE2E2', color: '#DC2626', dot: '#DC2626' },
};

export default function VehiclesPage() {
  const [vehicles, setVehicles] = useState(MOCK);
  const [showFuel, setShowFuel] = useState(null);

  useEffect(() => {
    vehiclesAPI.getAll().then(r => setVehicles(r.data)).catch(() => {});
  }, []);

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '16px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Fleet Management</h1>
          <p style={{ fontSize: 13, color: 'var(--text-mid)', marginTop: 2 }}>
            {vehicles.filter(v => v.status === 'available').length} available · {vehicles.filter(v => v.status === 'on_safari').length} on safari · {vehicles.filter(v => v.status === 'maintenance').length} in maintenance
          </p>
        </div>
        <button style={{ background: 'var(--primary-dark)', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
          ＋ Add Vehicle
        </button>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '22px 28px' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 16 }}>
          {vehicles.map(v => {
            const s = statusMap[v.status] || statusMap.available;
            return (
              <div key={v.id} style={{ background: 'var(--white)', borderRadius: 14, border: '1px solid var(--border)', overflow: 'hidden' }}>
                {/* Card header */}
                <div style={{ padding: '14px 16px', background: 'var(--bg)', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <div style={{ fontSize: 22 }}>🚙</div>
                  <span style={{ background: s.bg, color: s.color, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>
                    <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: s.dot, marginRight: 5 }}></span>
                    {s.label}
                  </span>
                </div>
                <div style={{ padding: '14px 16px' }}>
                  <div style={{ fontSize: 15, fontWeight: 700, marginBottom: 2 }}>{v.make} {v.model}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-mid)', marginBottom: 12 }}>{v.registration} · {v.year} · {v.seats} seats</div>
                  <div style={{ fontSize: 12, color: 'var(--text-mid)', marginBottom: 14 }}>
                    Last service: {v.last_service ? new Date(v.last_service).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                  </div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button style={{ flex: 1, padding: '7px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 12, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--text-mid)' }}>
                      ⛽ Log Fuel
                    </button>
                    <button style={{ flex: 1, padding: '7px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 12, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--text-mid)' }}>
                      🔧 Service
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
