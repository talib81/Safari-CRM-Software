import { useState } from 'react';

const monthlyRevenue = [
  { month: 'Jan', usd: 22000 }, { month: 'Feb', usd: 18000 },
  { month: 'Mar', usd: 31000 }, { month: 'Apr', usd: 26000 },
  { month: 'May', usd: 38400 }, { month: 'Jun', usd: 29000 },
];

const expenseBreakdown = [
  { label: 'Salaries',    pct: 40, color: '#2D6A4F', tzs: 12400000 },
  { label: 'Lodges',      pct: 32, color: '#2563EB', tzs: 9800000  },
  { label: 'Fuel',        pct: 14, color: '#F4A620', tzs: 4200000  },
  { label: 'Maintenance', pct: 7,  color: '#DC2626', tzs: 2100000  },
  { label: 'Office',      pct: 7,  color: '#9CA3AF', tzs: 2200000  },
];

const topPackages = [
  { name: '6-Day Serengeti Classic', bookings: 12, revenue: 50400 },
  { name: '10-Day Northern Circuit',  bookings: 5,  revenue: 41000 },
  { name: '4-Day Ngorongoro & Lake',  bookings: 9,  revenue: 25650 },
  { name: '3-Day Tarangire Explorer', bookings: 11, revenue: 21780 },
];

const maxRevenue = Math.max(...monthlyRevenue.map(m => m.usd));

export default function ReportsPage() {
  const [period, setPeriod] = useState('this_month');

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '16px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Reports & Analytics</h1>
          <p style={{ fontSize: 13, color: 'var(--text-mid)', marginTop: 2 }}>Business performance overview</p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          {[['this_month', 'This Month'], ['last_month', 'Last Month'], ['ytd', 'Year to Date']].map(([val, label]) => (
            <button key={val} onClick={() => setPeriod(val)}
              style={{ padding: '7px 14px', borderRadius: 8, fontSize: 12, fontWeight: 600, cursor: 'pointer', border: '1.5px solid', fontFamily: 'inherit', background: period === val ? 'var(--primary-dark)' : 'var(--white)', color: period === val ? '#fff' : 'var(--text-mid)', borderColor: period === val ? 'var(--primary-dark)' : 'var(--border)' }}>
              {label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '22px 28px' }}>
        {/* KPI Summary */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 14, marginBottom: 22 }}>
          {[
            { icon: '💵', label: 'Total Revenue', value: '$38,400', color: '#16A34A', bg: '#DCFCE7' },
            { icon: '📋', label: 'Total Bookings', value: '24', color: '#2563EB', bg: '#EFF6FF' },
            { icon: '💸', label: 'Total Expenses', value: 'TZS 30.7M', color: '#D97706', bg: '#FEF3C7' },
            { icon: '📈', label: 'Net Profit (est.)', value: '$22,100', color: '#2D6A4F', bg: '#ECFDF5' },
          ].map(k => (
            <div key={k.label} style={{ background: k.bg, borderRadius: 14, padding: '16px 18px' }}>
              <div style={{ fontSize: 24, marginBottom: 8 }}>{k.icon}</div>
              <div style={{ fontSize: 11, fontWeight: 600, color: k.color, marginBottom: 4 }}>{k.label}</div>
              <div style={{ fontSize: 22, fontWeight: 800, color: k.color }}>{k.value}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 18, marginBottom: 18 }}>
          {/* Revenue Bar Chart */}
          <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', padding: '18px 20px' }}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 18 }}>Monthly Revenue (USD)</div>
            <div style={{ display: 'flex', alignItems: 'flex-end', gap: 10, height: 140, paddingBottom: 28, position: 'relative' }}>
              {monthlyRevenue.map((m, i) => {
                const h = (m.usd / maxRevenue) * 120;
                const isCurrent = i === 4;
                return (
                  <div key={m.month} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', position: 'relative' }}>
                    <div style={{ fontSize: 10, color: isCurrent ? 'var(--primary)' : 'var(--text-mid)', fontWeight: isCurrent ? 700 : 400, marginBottom: 4 }}>
                      ${(m.usd / 1000).toFixed(0)}k
                    </div>
                    <div style={{ width: '100%', height: h, borderRadius: '4px 4px 0 0', background: isCurrent ? 'var(--primary)' : '#BBF7D0', transition: 'height 0.3s' }} />
                    <div style={{ position: 'absolute', bottom: -22, fontSize: 11, color: 'var(--text-mid)', fontWeight: isCurrent ? 700 : 400 }}>{m.month}</div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Expense Breakdown */}
          <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', padding: '18px 20px' }}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 16 }}>Expense Breakdown (TZS)</div>
            {expenseBreakdown.map(e => (
              <div key={e.label} style={{ marginBottom: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginBottom: 4 }}>
                  <span style={{ color: 'var(--text)', fontWeight: 500 }}>{e.label}</span>
                  <span style={{ color: 'var(--text-mid)', fontSize: 11 }}>TZS {(e.tzs / 1000000).toFixed(1)}M ({e.pct}%)</span>
                </div>
                <div style={{ height: 7, background: 'var(--bg)', borderRadius: 4, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${e.pct}%`, background: e.color, borderRadius: 4, transition: 'width 0.4s' }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Packages */}
        <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)', fontSize: 14, fontWeight: 700 }}>Top Performing Packages</div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg)' }}>
                {['Package', 'Bookings', 'Revenue (USD)', 'Share'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: 'var(--text-mid)', borderBottom: '1px solid var(--border)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {topPackages.map((p, i) => {
                const totalRev = topPackages.reduce((s, x) => s + x.revenue, 0);
                const share = Math.round((p.revenue / totalRev) * 100);
                return (
                  <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#FAFBFA'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}>
                    <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 500 }}>
                      <span style={{ fontSize: 11, color: 'var(--text-mid)', marginRight: 8 }}>#{i + 1}</span>
                      {p.name}
                    </td>
                    <td style={{ padding: '13px 16px', fontSize: 13 }}>{p.bookings} trips</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 700 }}>${p.revenue.toLocaleString()}</td>
                    <td style={{ padding: '13px 16px' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ flex: 1, height: 6, background: 'var(--bg)', borderRadius: 3, overflow: 'hidden', maxWidth: 100 }}>
                          <div style={{ height: '100%', width: `${share}%`, background: 'var(--primary)', borderRadius: 3 }} />
                        </div>
                        <span style={{ fontSize: 12, color: 'var(--text-mid)' }}>{share}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
