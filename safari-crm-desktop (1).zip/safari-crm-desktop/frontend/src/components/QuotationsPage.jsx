import { useState, useEffect } from 'react';
import { quotationsAPI } from '../api';

const MOCK = [
  { id: 1, quote_ref: 'QT-0041', customer_name: 'John Smith', total: 4956, currency: 'USD', status: 'accepted', valid_until: '2025-06-01', created_at: '2025-05-10' },
  { id: 2, quote_ref: 'QT-0040', customer_name: 'Amina Müller', total: 3366, currency: 'USD', status: 'sent', valid_until: '2025-05-28', created_at: '2025-05-08' },
  { id: 3, quote_ref: 'QT-0039', customer_name: 'Chen Wei', total: 2338, currency: 'USD', status: 'draft', valid_until: '2025-06-05', created_at: '2025-05-06' },
  { id: 4, quote_ref: 'QT-0038', customer_name: 'Sarah Okonkwo', total: 9676, currency: 'USD', status: 'expired', valid_until: '2025-05-01', created_at: '2025-04-20' },
];

const statusColors = {
  draft:    { bg: '#F3F4F6', color: '#6B7280' },
  sent:     { bg: '#EFF6FF', color: '#2563EB' },
  accepted: { bg: '#DCFCE7', color: '#16A34A' },
  rejected: { bg: '#FEE2E2', color: '#DC2626' },
  expired:  { bg: '#FEF3C7', color: '#D97706' },
};

export default function QuotationsPage() {
  const [quotes, setQuotes] = useState(MOCK);

  useEffect(() => {
    quotationsAPI.getAll().then(res => setQuotes(res.data)).catch(() => {});
  }, []);

  async function handleDownloadPDF(id, ref) {
    try {
      const res = await quotationsAPI.generatePDF(id);
      if (window.electronAPI) {
        await window.electronAPI.saveFile({ data: Array.from(new Uint8Array(res.data)), filename: `${ref}.pdf` });
      } else {
        const blob = new Blob([res.data], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url; a.download = `${ref}.pdf`; a.click();
      }
    } catch { alert('PDF generation requires the backend to be running.'); }
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '16px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Quotations</h1>
          <p style={{ fontSize: 13, color: 'var(--text-mid)', marginTop: 2 }}>{quotes.length} quotations</p>
        </div>
        <button style={{ background: 'var(--primary-dark)', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
          ＋ New Quote
        </button>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '22px 28px' }}>
        <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg)' }}>
                {['Quote Ref', 'Customer', 'Total', 'Currency', 'Valid Until', 'Status', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: 'var(--text-mid)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {quotes.map((q, i) => {
                const s = statusColors[q.status] || statusColors.draft;
                return (
                  <tr key={q.id || i} style={{ borderBottom: '1px solid var(--border)' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#FAFBFA'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}>
                    <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--primary)', fontWeight: 600 }}>{q.quote_ref}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13 }}>{q.customer_name}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 700 }}>${q.total?.toLocaleString()}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--text-mid)' }}>{q.currency}</td>
                    <td style={{ padding: '13px 16px', fontSize: 12, color: 'var(--text-mid)' }}>
                      {q.valid_until ? new Date(q.valid_until).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                    </td>
                    <td style={{ padding: '13px 16px' }}>
                      <span style={{ background: s.bg, color: s.color, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>
                        {q.status?.charAt(0).toUpperCase() + q.status?.slice(1)}
                      </span>
                    </td>
                    <td style={{ padding: '13px 16px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button onClick={() => handleDownloadPDF(q.id, q.quote_ref)}
                          style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--primary)' }}>PDF</button>
                        <button style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--text-mid)' }}>Send</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
