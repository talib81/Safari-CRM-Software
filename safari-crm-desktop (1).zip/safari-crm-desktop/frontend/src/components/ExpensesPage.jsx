import { useState, useEffect } from 'react';
import { expensesAPI } from '../api';

const MOCK = [
  { id: 1, category: 'fuel', description: 'Fuel for T 789 ABC — Serengeti trip', amount_tzs: 280000, expense_date: '2025-05-20', recorded_by_name: 'Admin' },
  { id: 2, category: 'salaries', description: 'May 2025 guide salaries', amount_tzs: 3200000, expense_date: '2025-05-01', recorded_by_name: 'Grace Masanja' },
  { id: 3, category: 'repairs', description: 'Land Cruiser T 123 GHI engine check', amount_tzs: 450000, expense_date: '2025-05-03', recorded_by_name: 'Admin' },
  { id: 4, category: 'office', description: 'Office supplies and printing', amount_tzs: 85000, expense_date: '2025-05-12', recorded_by_name: 'Admin' },
  { id: 5, category: 'marketing', description: 'TripAdvisor premium listing', amount_tzs: 320000, expense_date: '2025-05-15', recorded_by_name: 'Admin' },
  { id: 6, category: 'fuel', description: 'Fuel for T 456 DEF — Ngorongoro', amount_tzs: 195000, expense_date: '2025-05-18', recorded_by_name: 'David Kimani' },
];

const catColors = {
  fuel:      { bg: '#FEF3C7', color: '#D97706', icon: '⛽' },
  salaries:  { bg: '#EFF6FF', color: '#2563EB', icon: '💰' },
  repairs:   { bg: '#FEE2E2', color: '#DC2626', icon: '🔧' },
  office:    { bg: '#F3F4F6', color: '#6B7280', icon: '🖨️' },
  marketing: { bg: '#FAF5FF', color: '#7C3AED', icon: '📣' },
  other:     { bg: '#F0FDF4', color: '#16A34A', icon: '📦' },
};

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState(MOCK);
  const [showAdd, setShowAdd]   = useState(false);
  const [newExp, setNewExp]     = useState({ category: 'fuel', description: '', amount_tzs: '', expense_date: '' });

  useEffect(() => {
    expensesAPI.getAll().then(r => setExpenses(r.data)).catch(() => {});
  }, []);

  const total = expenses.reduce((s, e) => s + (e.amount_tzs || 0), 0);

  async function handleAdd() {
    try {
      const res = await expensesAPI.create(newExp);
      setExpenses([res.data, ...expenses]);
    } catch {
      setExpenses([{ ...newExp, id: Date.now(), recorded_by_name: 'Admin' }, ...expenses]);
    }
    setShowAdd(false);
    setNewExp({ category: 'fuel', description: '', amount_tzs: '', expense_date: '' });
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '16px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Expenses</h1>
          <p style={{ fontSize: 13, color: 'var(--text-mid)', marginTop: 2 }}>Total this month: TZS {total.toLocaleString()}</p>
        </div>
        <button onClick={() => setShowAdd(true)}
          style={{ background: 'var(--primary-dark)', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
          ＋ Add Expense
        </button>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '22px 28px' }}>
        {/* Summary by category */}
        <div style={{ display: 'flex', gap: 12, marginBottom: 20, flexWrap: 'wrap' }}>
          {Object.entries(catColors).map(([cat, cfg]) => {
            const catTotal = expenses.filter(e => e.category === cat).reduce((s, e) => s + (e.amount_tzs || 0), 0);
            if (!catTotal) return null;
            return (
              <div key={cat} style={{ background: cfg.bg, borderRadius: 12, padding: '12px 16px', minWidth: 130 }}>
                <div style={{ fontSize: 18, marginBottom: 4 }}>{cfg.icon}</div>
                <div style={{ fontSize: 11, fontWeight: 600, color: cfg.color, textTransform: 'capitalize', marginBottom: 2 }}>{cat}</div>
                <div style={{ fontSize: 14, fontWeight: 700, color: cfg.color }}>TZS {catTotal.toLocaleString()}</div>
              </div>
            );
          })}
        </div>

        {/* Add form */}
        {showAdd && (
          <div style={{ background: 'var(--white)', borderRadius: 14, border: '1px solid var(--border)', padding: '18px 20px', marginBottom: 20 }}>
            <div style={{ fontSize: 14, fontWeight: 700, marginBottom: 14 }}>Add Expense</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 12, marginBottom: 14 }}>
              {[
                { label: 'Category', key: 'category', type: 'select', opts: Object.keys(catColors) },
                { label: 'Description', key: 'description', type: 'text', placeholder: 'Describe the expense' },
                { label: 'Amount (TZS)', key: 'amount_tzs', type: 'number', placeholder: '0' },
                { label: 'Date', key: 'expense_date', type: 'date' },
              ].map(f => (
                <div key={f.key}>
                  <label style={{ fontSize: 11, fontWeight: 600, color: 'var(--text-mid)', display: 'block', marginBottom: 4 }}>{f.label}</label>
                  {f.type === 'select' ? (
                    <select value={newExp[f.key]} onChange={e => setNewExp({ ...newExp, [f.key]: e.target.value })}
                      style={{ width: '100%', padding: '9px 12px', border: '1.5px solid var(--border)', borderRadius: 8, fontSize: 13, fontFamily: 'inherit', outline: 'none' }}>
                      {f.opts.map(o => <option key={o} value={o}>{o.charAt(0).toUpperCase() + o.slice(1)}</option>)}
                    </select>
                  ) : (
                    <input type={f.type} value={newExp[f.key]} placeholder={f.placeholder}
                      onChange={e => setNewExp({ ...newExp, [f.key]: e.target.value })}
                      style={{ width: '100%', padding: '9px 12px', border: '1.5px solid var(--border)', borderRadius: 8, fontSize: 13, fontFamily: 'inherit', outline: 'none' }} />
                  )}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 10, justifyContent: 'flex-end' }}>
              <button onClick={() => setShowAdd(false)} style={{ padding: '8px 16px', borderRadius: 8, border: '1.5px solid var(--border)', background: 'var(--white)', fontSize: 13, cursor: 'pointer', fontFamily: 'inherit' }}>Cancel</button>
              <button onClick={handleAdd} style={{ padding: '8px 16px', borderRadius: 8, border: 'none', background: 'var(--primary-dark)', color: '#fff', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>Save Expense</button>
            </div>
          </div>
        )}

        <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg)' }}>
                {['Date', 'Category', 'Description', 'Amount (TZS)', 'Recorded By'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: 'var(--text-mid)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {expenses.map((exp, i) => {
                const cfg = catColors[exp.category] || catColors.other;
                return (
                  <tr key={exp.id || i} style={{ borderBottom: '1px solid var(--border)' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#FAFBFA'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}>
                    <td style={{ padding: '13px 16px', fontSize: 12, color: 'var(--text-mid)' }}>
                      {exp.expense_date ? new Date(exp.expense_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) : '—'}
                    </td>
                    <td style={{ padding: '13px 16px' }}>
                      <span style={{ background: cfg.bg, color: cfg.color, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>
                        {cfg.icon} {exp.category?.charAt(0).toUpperCase() + exp.category?.slice(1)}
                      </span>
                    </td>
                    <td style={{ padding: '13px 16px', fontSize: 13 }}>{exp.description}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 700 }}>TZS {(exp.amount_tzs || 0).toLocaleString()}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--text-mid)' }}>{exp.recorded_by_name}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
