const navItems = [
  { label: 'Dashboard',    emoji: '⊞' },
  { label: 'Bookings',     emoji: '📅' },
  { label: 'Reservations', emoji: '🕐' },
  { label: 'Quotations',   emoji: '📋' },
  { label: 'Invoices',     emoji: '🧾' },
  { label: 'Expenses',     emoji: '💸' },
  { label: 'HR & Staff',   emoji: '👥' },
  { label: 'Fleet',        emoji: '🚙' },
  { label: 'Reports',      emoji: '📊' },
  { label: 'Tax / TRA',    emoji: '⚖️' },
];

export default function Sidebar({ activePage, onNavigate, user, onLogout }) {
  return (
    <aside style={{
      width: 200, minWidth: 200, background: 'var(--sidebar)',
      display: 'flex', flexDirection: 'column', height: '100vh',
      overflow: 'hidden',
    }}>
      {/* Logo */}
      <div style={{
        padding: '18px 16px 14px', display: 'flex', alignItems: 'center',
        gap: 10, borderBottom: '1px solid rgba(255,255,255,0.07)',
        flexShrink: 0,
      }}>
        <div style={{
          width: 38, height: 38, borderRadius: 10, background: 'var(--accent)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 18, flexShrink: 0,
        }}>🦁</div>
        <div>
          <div style={{ color: '#fff', fontWeight: 700, fontSize: 12, lineHeight: 1.3 }}>Predictor</div>
          <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: 11 }}>Safari Club</div>
        </div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '10px 8px', overflowY: 'auto' }}>
        {navItems.map(item => {
          const isActive = activePage === item.label;
          return (
            <div
              key={item.label}
              onClick={() => onNavigate(item.label)}
              style={{
                display: 'flex', alignItems: 'center', gap: 9,
                padding: '8px 12px', borderRadius: 8, cursor: 'pointer',
                marginBottom: 2, transition: 'background 0.15s',
                background: isActive ? 'var(--sidebar-active)' : 'transparent',
                color: isActive ? '#fff' : 'rgba(255,255,255,0.6)',
                fontSize: 13, fontWeight: isActive ? 600 : 400,
              }}
              onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = 'var(--sidebar-hover)'; e.currentTarget.style.color = 'rgba(255,255,255,0.85)'; }}
              onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'rgba(255,255,255,0.6)'; }}
            >
              <span style={{ fontSize: 15 }}>{item.emoji}</span>
              {item.label}
            </div>
          );
        })}
      </nav>

      {/* User / logout */}
      <div style={{
        padding: '12px 8px', borderTop: '1px solid rgba(255,255,255,0.07)', flexShrink: 0,
      }}>
        <div style={{
          padding: '8px 12px', borderRadius: 8, marginBottom: 4,
          color: 'rgba(255,255,255,0.6)', fontSize: 12,
        }}>
          <div style={{ fontWeight: 600, color: '#fff', marginBottom: 1 }}>{user?.name}</div>
          <div style={{ fontSize: 11 }}>{user?.role}</div>
        </div>
        <div
          onClick={onLogout}
          style={{
            display: 'flex', alignItems: 'center', gap: 9,
            padding: '8px 12px', borderRadius: 8, cursor: 'pointer',
            color: 'rgba(255,255,255,0.5)', fontSize: 13,
          }}
          onMouseEnter={e => { e.currentTarget.style.background = 'rgba(220,38,38,0.15)'; e.currentTarget.style.color = '#FCA5A5'; }}
          onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = 'rgba(255,255,255,0.5)'; }}
        >
          <span>🚪</span> Sign out
        </div>
      </div>
    </aside>
  );
}
