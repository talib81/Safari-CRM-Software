import { useState, useEffect } from 'react';
import { bookingsAPI } from '../api';

const MOCK = [
  { id: 1, booking_ref: 'SAF-0091', customer_name: 'John Smith', package_name: '6-Day Serengeti', start_date: '2025-06-10', end_date: '2025-06-16', status: 'confirmed', num_adults: 2, total: 4200 },
  { id: 2, booking_ref: 'SAF-0090', customer_name: 'Amina Müller', package_name: 'Ngorongoro + Lake', start_date: '2025-06-05', end_date: '2025-06-09', status: 'pending', num_adults: 3, total: 2850 },
  { id: 3, booking_ref: 'SAF-0089', customer_name: 'Chen Wei', package_name: '3-Day Tarangire', start_date: '2025-05-28', end_date: '2025-05-30', status: 'confirmed', num_adults: 2, total: 1980 },
  { id: 4, booking_ref: 'SAF-0088', customer_name: 'Sarah Okonkwo', package_name: '10-Day Circuit', start_date: '2025-07-01', end_date: '2025-07-11', status: 'enquiry', num_adults: 4, total: 8200 },
  { id: 5, booking_ref: 'SAF-0087', customer_name: 'Hans Berger', package_name: '4-Day Ngorongoro', start_date: '2025-06-20', end_date: '2025-06-24', status: 'cancelled', num_adults: 2, total: 2400 },
];

const statusColors = {
  confirmed:   { bg: '#DCFCE7', color: '#16A34A' },
  pending:     { bg: '#FEF3C7', color: '#D97706' },
  enquiry:     { bg: '#EFF6FF', color: '#2563EB' },
  cancelled:   { bg: '#FEE2E2', color: '#DC2626' },
  in_progress: { bg: '#F0FDF4', color: '#16A34A' },
  completed:   { bg: '#F3F4F6', color: '#6B7280' },
};

export default function BookingsPage() {
  const [bookings, setBookings] = useState(MOCK);
  const [search, setSearch]     = useState('');
  const [filter, setFilter]     = useState('all');
  const [showForm, setShowForm] = useState(false);

  useEffect(() => {
    bookingsAPI.getAll().then(res => setBookings(res.data.bookings || res.data)).catch(() => {});
  }, []);

  const filtered = bookings.filter(b => {
    const matchSearch = b.customer_name?.toLowerCase().includes(search.toLowerCase()) ||
      b.booking_ref?.toLowerCase().includes(search.toLowerCase()) ||
      b.package_name?.toLowerCase().includes(search.toLowerCase());
    const matchFilter = filter === 'all' || b.status === filter;
    return matchSearch && matchFilter;
  });

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '16px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700 }}>Bookings</h1>
          <p style={{ fontSize: 13, color: 'var(--text-mid)', marginTop: 2 }}>{bookings.length} total bookings</p>
        </div>
        <button onClick={() => setShowForm(true)}
          style={{ background: 'var(--primary-dark)', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
          ＋ New Booking
        </button>
      </div>

      <div style={{ flex: 1, overflow: 'auto', padding: '22px 28px' }}>
        {/* Filters */}
        <div style={{ display: 'flex', gap: 10, marginBottom: 16, alignItems: 'center' }}>
          <input
            placeholder="Search by ref, customer, package…"
            value={search} onChange={e => setSearch(e.target.value)}
            style={{ flex: 1, maxWidth: 320, padding: '9px 14px', border: '1.5px solid var(--border)', borderRadius: 10, fontSize: 13, fontFamily: 'inherit', outline: 'none', background: 'var(--white)' }}
          />
          {['all', 'confirmed', 'pending', 'enquiry', 'in_progress', 'cancelled'].map(s => (
            <button key={s} onClick={() => setFilter(s)}
              style={{
                padding: '6px 14px', borderRadius: 20, fontSize: 12, fontWeight: 600, cursor: 'pointer',
                border: '1.5px solid', fontFamily: 'inherit',
                background: filter === s ? 'var(--primary-dark)' : 'var(--white)',
                color: filter === s ? '#fff' : 'var(--text-mid)',
                borderColor: filter === s ? 'var(--primary-dark)' : 'var(--border)',
              }}>
              {s === 'all' ? 'All' : s.charAt(0).toUpperCase() + s.slice(1).replace('_', ' ')}
            </button>
          ))}
        </div>

        {/* Table */}
        <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ background: 'var(--bg)' }}>
                {['Ref', 'Customer', 'Package', 'Dates', 'Pax', 'Status', 'Total (USD)', 'Actions'].map(h => (
                  <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: 'var(--text-mid)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((b, i) => {
                const s = statusColors[b.status] || statusColors.enquiry;
                return (
                  <tr key={b.id || i} style={{ borderBottom: '1px solid var(--border)' }}
                    onMouseEnter={e => e.currentTarget.style.background = '#FAFBFA'}
                    onMouseLeave={e => e.currentTarget.style.background = ''}>
                    <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--primary)', fontWeight: 600 }}>{b.booking_ref}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 500 }}>{b.customer_name}</td>
                    <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--text-mid)' }}>{b.package_name}</td>
                    <td style={{ padding: '13px 16px', fontSize: 12, color: 'var(--text-mid)' }}>
                      {new Date(b.start_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })} – {new Date(b.end_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                    </td>
                    <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--text-mid)' }}>{b.num_adults} adults</td>
                    <td style={{ padding: '13px 16px' }}>
                      <span style={{ background: s.bg, color: s.color, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>
                        {b.status?.charAt(0).toUpperCase() + b.status?.slice(1).replace('_', ' ')}
                      </span>
                    </td>
                    <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 700 }}>${(b.total || 0).toLocaleString()}</td>
                    <td style={{ padding: '13px 16px' }}>
                      <div style={{ display: 'flex', gap: 6 }}>
                        <button style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--text-mid)' }}>View</button>
                        <button style={{ padding: '4px 10px', borderRadius: 6, border: '1px solid var(--border)', background: 'var(--white)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit', color: 'var(--text-mid)' }}>Edit</button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr><td colSpan={8} style={{ padding: '40px', textAlign: 'center', color: 'var(--text-light)', fontSize: 13 }}>No bookings found</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
