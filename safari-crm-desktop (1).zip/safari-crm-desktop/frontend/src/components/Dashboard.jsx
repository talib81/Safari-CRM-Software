import { useState, useEffect } from 'react';
import { bookingsAPI, reportsAPI } from '../api';

const MOCK_BOOKINGS = [
  { id: 1, booking_ref: 'SAF-0091', customer: { full_name: 'John Smith', initials: 'JS', color: '#7C3AED' }, package: { name: '6-Day Serengeti' }, start_date: '2025-06-10', end_date: '2025-06-16', status: 'confirmed', total: 4200 },
  { id: 2, booking_ref: 'SAF-0090', customer: { full_name: 'Amina Müller', initials: 'AM', color: '#DB2777' }, package: { name: 'Ngorongoro + Lake' }, start_date: '2025-06-05', end_date: '2025-06-09', status: 'pending', total: 2850 },
  { id: 3, booking_ref: 'SAF-0089', customer: { full_name: 'Chen Wei', initials: 'CW', color: '#0891B2' }, package: { name: '3-Day Tarangire' }, start_date: '2025-05-28', end_date: '2025-05-30', status: 'confirmed', total: 1980 },
];

const MOCK_STATS = {
  bookings_this_month: 24,
  revenue_usd: 38400,
  outstanding_invoices: 7,
  vehicles_on_safari: 5,
  vehicles_total: 8,
  revenue_growth: 18,
  bookings_growth: 12,
};

const statusColors = {
  confirmed: { bg: '#DCFCE7', color: '#16A34A' },
  pending:   { bg: '#FEF3C7', color: '#D97706' },
  enquiry:   { bg: '#EFF6FF', color: '#2563EB' },
  cancelled: { bg: '#FEE2E2', color: '#DC2626' },
  in_progress:{ bg: '#F0FDF4', color: '#16A34A' },
};

function KpiCard({ icon, iconBg, label, value, sub, subColor, link }) {
  return (
    <div style={{
      background: 'var(--white)', borderRadius: 14, padding: '18px 20px',
      border: '1px solid var(--border)', flex: 1,
    }}>
      <div style={{ width: 40, height: 40, borderRadius: 10, background: iconBg, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, marginBottom: 12 }}>{icon}</div>
      <div style={{ fontSize: 12, color: 'var(--text-mid)', fontWeight: 500, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 800, color: 'var(--text)', marginBottom: 8, lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 12, color: subColor || 'var(--success)', display: 'flex', alignItems: 'center', gap: 4 }}>{sub}</div>
    </div>
  );
}

export default function Dashboard({ onNavigate }) {
  const [bookings, setBookings] = useState(MOCK_BOOKINGS);
  const [stats, setStats]       = useState(MOCK_STATS);
  const [loading, setLoading]   = useState(false);
  const [step, setStep]         = useState(0);
  const [form, setForm]         = useState({ name: '', nationality: 'United Kingdom', passport: '', expiry: '', email: '', phone: '' });

  useEffect(() => {
    async function loadData() {
      setLoading(true);
      try {
        const [statsRes, bookingsRes] = await Promise.all([
          reportsAPI.dashboard(),
          bookingsAPI.getAll({ limit: 5 }),
        ]);
        setStats(statsRes.data);
        setBookings(bookingsRes.data.bookings || bookingsRes.data);
      } catch {
        // Backend not connected — keep mock data
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  const stepLabels = ['1. Customer', '2. Package', '3. Reservations', '4. Quotation', '5. Confirm'];

  function formatDate(d) {
    if (!d) return '';
    const dt = new Date(d);
    return dt.toLocaleDateString('en-GB', { month: 'short', day: 'numeric' });
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      {/* Top bar */}
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '16px 28px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div>
          <h1 style={{ fontSize: 20, fontWeight: 700, color: 'var(--text)' }}>Welcome back, Admin 👋</h1>
          <p style={{ fontSize: 13, color: 'var(--text-mid)', marginTop: 2 }}>Here's what's happening with your safari business today.</p>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button
            onClick={() => onNavigate('Bookings')}
            style={{ background: 'var(--primary-dark)', color: '#fff', border: 'none', borderRadius: 10, padding: '10px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 6 }}
          >
            ＋ New booking ↗
          </button>
          <div style={{ width: 40, height: 40, borderRadius: '50%', background: 'var(--accent)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 800, color: 'var(--primary-dark)' }}>PSC</div>
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflow: 'auto', padding: '22px 28px' }}>
        {/* KPI Cards */}
        <div style={{ display: 'flex', gap: 16, marginBottom: 22 }}>
          <KpiCard icon="📅" iconBg="#ECFDF5" label="Bookings this month" value={stats.bookings_this_month} sub={`↑ ${stats.bookings_growth}% from last month`} />
          <KpiCard icon="💵" iconBg="#F0FDF4" label="Revenue (USD)" value={`$${stats.revenue_usd?.toLocaleString()}`} sub={`↑ ${stats.revenue_growth}% from last month`} />
          <KpiCard icon="🧾" iconBg="#FEF9EE" label="Outstanding invoices" value={stats.outstanding_invoices} sub="View invoices →" subColor="var(--warning)" link />
          <KpiCard icon="🚙" iconBg="#EFF6FF" label="Vehicles on safari" value={`${stats.vehicles_on_safari} / ${stats.vehicles_total}`} sub="View fleet →" subColor="var(--info)" link />
        </div>

        {/* Recent Bookings */}
        <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)', marginBottom: 22 }}>
          <div style={{ padding: '16px 20px 12px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div style={{ fontSize: 15, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 8 }}>
              📅 Recent bookings
            </div>
            <div style={{ fontSize: 13, color: 'var(--primary)', fontWeight: 600, cursor: 'pointer' }} onClick={() => onNavigate('Bookings')}>
              View all bookings →
            </div>
          </div>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ background: 'var(--bg)' }}>
                  {['Ref', 'Customer', 'Package', 'Dates', 'Status', 'Total (USD)', ''].map(h => (
                    <th key={h} style={{ padding: '10px 16px', textAlign: 'left', fontSize: 12, fontWeight: 600, color: 'var(--text-mid)', borderTop: '1px solid var(--border)', borderBottom: '1px solid var(--border)' }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {bookings.map((b, i) => {
                  const s = statusColors[b.status] || statusColors.enquiry;
                  const name = b.customer?.full_name || b.customer_name || '';
                  const initials = b.customer?.initials || name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase();
                  const color = b.customer?.color || '#6B7280';
                  return (
                    <tr key={b.id || i} style={{ borderBottom: '1px solid var(--border)', cursor: 'pointer' }}
                      onMouseEnter={e => e.currentTarget.style.background = '#FAFBFA'}
                      onMouseLeave={e => e.currentTarget.style.background = ''}>
                      <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--primary)', fontWeight: 600 }}>{b.booking_ref}</td>
                      <td style={{ padding: '13px 16px', fontSize: 13 }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <div style={{ width: 28, height: 28, borderRadius: '50%', background: color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, color: '#fff', flexShrink: 0 }}>{initials}</div>
                          {name}
                        </div>
                      </td>
                      <td style={{ padding: '13px 16px', fontSize: 13 }}>{b.package?.name || b.package_name}</td>
                      <td style={{ padding: '13px 16px', fontSize: 13, color: 'var(--text-mid)' }}>
                        📅 {formatDate(b.start_date)} – {formatDate(b.end_date)}
                      </td>
                      <td style={{ padding: '13px 16px' }}>
                        <span style={{ background: s.bg, color: s.color, borderRadius: 20, padding: '3px 10px', fontSize: 11, fontWeight: 600 }}>
                          {b.status?.charAt(0).toUpperCase() + b.status?.slice(1)}
                        </span>
                      </td>
                      <td style={{ padding: '13px 16px', fontSize: 13, fontWeight: 700 }}>
                        ${(b.total || b.total_usd || 0).toLocaleString()}
                      </td>
                      <td style={{ padding: '13px 16px' }}>
                        <span style={{ color: 'var(--text-light)', cursor: 'pointer', fontSize: 16 }}>⋮</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* New Booking Form */}
        <div style={{ background: 'var(--white)', borderRadius: 16, border: '1px solid var(--border)' }}>
          <div style={{ padding: '16px 20px 14px', borderBottom: '1px solid var(--border)' }}>
            <div style={{ fontSize: 15, fontWeight: 700 }}>New booking form</div>
          </div>

          {/* Stepper */}
          <div style={{ display: 'flex', alignItems: 'center', padding: '14px 20px', borderBottom: '1px solid var(--border)', overflowX: 'auto', gap: 0 }}>
            {stepLabels.map((s, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', flex: i < stepLabels.length - 1 ? 1 : 'none' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 7, cursor: 'pointer', flexShrink: 0 }} onClick={() => i <= step && setStep(i)}>
                  <div style={{
                    width: 24, height: 24, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontWeight: 700, flexShrink: 0,
                    background: i < step ? 'var(--success-bg)' : i === step ? 'var(--primary)' : 'var(--bg)',
                    color: i < step ? 'var(--success)' : i === step ? '#fff' : 'var(--text-light)',
                    border: i < step ? 'none' : i === step ? 'none' : '1.5px solid var(--border)',
                  }}>{i < step ? '✓' : i + 1}</div>
                  <span style={{ fontSize: 12, fontWeight: 600, color: i === step ? 'var(--primary)' : i < step ? 'var(--success)' : 'var(--text-light)', whiteSpace: 'nowrap' }}>{s}</span>
                </div>
                {i < stepLabels.length - 1 && <div style={{ flex: 1, height: 1.5, background: i < step ? 'rgba(22,163,74,0.3)' : 'var(--border)', margin: '0 8px', minWidth: 12 }} />}
              </div>
            ))}
          </div>

          {/* Form step 1 */}
          {step === 0 && (
            <div style={{ padding: '20px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                {[
                  ['Full name', 'name', 'text', 'e.g. Jane Okonkwo'],
                  ['Nationality', 'nationality', 'select', ''],
                  ['Passport number', 'passport', 'text', 'AB123456'],
                  ['Passport expiry', 'expiry', 'text', '2028-09-01'],
                  ['Email', 'email', 'email', 'jane@example.com'],
                  ['Phone / WhatsApp', 'phone', 'text', '+44 7911 123456'],
                ].map(([label, key, type, placeholder]) => (
                  <div key={key}>
                    <label style={{ fontSize: 12, fontWeight: 600, color: 'var(--text-mid)', display: 'block', marginBottom: 5 }}>{label}</label>
                    {type === 'select' ? (
                      <select value={form[key]} onChange={e => setForm({ ...form, [key]: e.target.value })}
                        style={{ width: '100%', padding: '10px 12px', border: '1.5px solid var(--border)', borderRadius: 10, fontSize: 13, fontFamily: 'inherit', background: 'var(--white)', outline: 'none', color: 'var(--text)' }}>
                        {['United Kingdom','United States','Germany','France','China','South Africa','Tanzania','Other'].map(n => <option key={n}>{n}</option>)}
                      </select>
                    ) : (
                      <input type={type} value={form[key]} placeholder={placeholder}
                        onChange={e => setForm({ ...form, [key]: e.target.value })}
                        style={{ width: '100%', padding: '10px 12px', border: '1.5px solid var(--border)', borderRadius: 10, fontSize: 13, fontFamily: 'inherit', outline: 'none', color: 'var(--text)', background: 'var(--bg)' }} />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {step > 0 && (
            <div style={{ padding: '40px 20px', textAlign: 'center', color: 'var(--text-mid)' }}>
              <div style={{ fontSize: 36, marginBottom: 10 }}>{ ['🗓️','🏕️','💰','✅'][step - 1] }</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--text)', marginBottom: 6 }}>
                { ['Select Package', 'Assign Resources', 'Quotation & Costs', 'Confirm Booking'][step - 1] }
              </div>
              <div style={{ fontSize: 13 }}>Connect your Node.js backend to enable this step.</div>
            </div>
          )}

          <div style={{ padding: '14px 20px', borderTop: '1px solid var(--border)', display: 'flex', justifyContent: 'flex-end', gap: 10 }}>
            {step > 0 && (
              <button onClick={() => setStep(s => s - 1)} style={{ background: 'var(--white)', border: '1.5px solid var(--border)', borderRadius: 10, padding: '9px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
                ← Back
              </button>
            )}
            <button style={{ background: 'var(--white)', border: '1.5px solid var(--border)', borderRadius: 10, padding: '9px 18px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
              Save draft
            </button>
            <button onClick={() => step < 4 ? setStep(s => s + 1) : alert('Booking created!')}
              style={{ background: 'var(--primary-dark)', color: '#fff', border: 'none', borderRadius: 10, padding: '9px 20px', fontSize: 13, fontWeight: 600, cursor: 'pointer', fontFamily: 'inherit' }}>
              {step === 4 ? 'Confirm booking ✓' : `Next: ${stepLabels[step + 1]?.slice(3)} →`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
