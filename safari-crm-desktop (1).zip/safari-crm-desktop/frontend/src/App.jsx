import { useState, useEffect } from 'react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Sidebar from './components/Sidebar';
import BookingsPage from './components/BookingsPage';
import QuotationsPage from './components/QuotationsPage';
import InvoicesPage from './components/InvoicesPage';
import VehiclesPage from './components/VehiclesPage';
import StaffPage from './components/StaffPage';
import ExpensesPage from './components/ExpensesPage';
import ReportsPage from './components/ReportsPage';

export default function App() {
  const [user, setUser]         = useState(null);
  const [activePage, setPage]   = useState('Dashboard');
  const [checking, setChecking] = useState(true);

  // Check for saved session on startup
  useEffect(() => {
    const token = localStorage.getItem('safari_crm_token');
    if (token) {
      // In a real app: validate token with /api/auth/me
      // For demo: auto-login with saved token
      setUser({ name: 'Admin', role: 'admin', email: 'admin@safariclub.tz' });
    }
    setChecking(false);
  }, []);

  function handleLogout() {
    localStorage.removeItem('safari_crm_token');
    setUser(null);
    setPage('Dashboard');
  }

  if (checking) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100vh', background: 'var(--bg)' }}>
        <div style={{ fontSize: 13, color: 'var(--text-mid)' }}>Loading…</div>
      </div>
    );
  }

  if (!user) {
    return <Login onLogin={setUser} />;
  }

  const pages = {
    Dashboard:    <Dashboard onNavigate={setPage} />,
    Bookings:     <BookingsPage />,
    Reservations: <PlaceholderPage title="Reservations" icon="🏕️" />,
    Quotations:   <QuotationsPage />,
    Invoices:     <InvoicesPage />,
    Expenses:     <ExpensesPage />,
    'HR & Staff': <StaffPage />,
    Fleet:        <VehiclesPage />,
    Reports:      <ReportsPage />,
    'Tax / TRA':  <PlaceholderPage title="Tax / TRA" icon="🧾" />,
  };

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
      <Sidebar activePage={activePage} onNavigate={setPage} user={user} onLogout={handleLogout} />
      <main style={{ flex: 1, overflow: 'auto', display: 'flex', flexDirection: 'column' }}>
        {pages[activePage] || pages['Dashboard']}
      </main>
    </div>
  );
}

function PlaceholderPage({ title, icon }) {
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--border)', padding: '18px 28px' }}>
        <h1 style={{ fontSize: 20, fontWeight: 700 }}>{title}</h1>
      </div>
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 12, color: 'var(--text-mid)' }}>
        <div style={{ fontSize: 48 }}>{icon}</div>
        <div style={{ fontSize: 16, fontWeight: 600, color: 'var(--text)' }}>{title}</div>
        <div style={{ fontSize: 13 }}>This module is ready to be connected to your backend.</div>
      </div>
    </div>
  );
}
