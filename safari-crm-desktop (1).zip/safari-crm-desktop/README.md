# 🦁 Predictor Safari Club CRM — Desktop App

A complete Windows desktop CRM/ERP application for safari businesses in Tanzania.
Built with **Electron + React (Vite) + Node.js/Express + MySQL**.

---

## 📁 Project Structure

```
safari-crm-desktop/
├── electron/           ← Desktop window host
│   ├── main.js
│   └── preload.js
├── frontend/           ← React UI (Vite)
│   └── src/
│       ├── App.jsx
│       ├── api.js
│       └── components/
│           ├── Login.jsx
│           ├── Sidebar.jsx
│           ├── Dashboard.jsx
│           ├── BookingsPage.jsx
│           ├── QuotationsPage.jsx
│           ├── InvoicesPage.jsx
│           ├── VehiclesPage.jsx
│           ├── StaffPage.jsx
│           ├── ExpensesPage.jsx
│           └── ReportsPage.jsx
├── backend/            ← Node.js/Express API
│   └── src/
│       ├── app.js
│       ├── config/database.js
│       ├── middleware/auth.js
│       └── routes/
│           ├── auth.js
│           ├── bookings.js
│           ├── customers.js
│           ├── packages.js
│           ├── quotations.js
│           ├── invoices.js
│           ├── vehicles.js
│           ├── staff.js
│           ├── expenses.js
│           └── reports.js
├── package.json        ← Root (Electron)
└── README.md
```

---

## 🚀 Setup Instructions

### Step 1 — Install Node.js
Download and install **Node.js 18+** from https://nodejs.org

### Step 2 — Install MySQL
Download **MySQL Community Server** from https://dev.mysql.com/downloads/
- During install, set a root password and remember it
- Create a database:
```sql
CREATE DATABASE safari_crm CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### Step 3 — Configure the backend
```bash
cd backend
cp .env.example .env
```
Edit `.env` and set your MySQL password:
```
DB_PASS=your_mysql_password_here
```

### Step 4 — Install all dependencies
```bash
# From the root folder (safari-crm-desktop/)

# Install Electron deps
npm install

# Install frontend deps
cd frontend && npm install && cd ..

# Install backend deps
cd backend && npm install && cd ..
```

### Step 5 — Run in development mode
Open **two terminals**:

**Terminal 1 — Start the backend API:**
```bash
cd backend
npm run dev
# API runs at http://localhost:3000
```

**Terminal 2 — Start the desktop app:**
```bash
# From root folder
npm run dev
# Opens the Electron window
```

---

## 🔐 Default Login Credentials

| Role       | Email                      | Password  |
|------------|----------------------------|-----------|
| Admin      | admin@safariclub.tz        | admin123  |
| Accountant | grace@safariclub.tz        | admin123  |
| Staff      | joseph@safariclub.tz       | admin123  |

---

## 📦 Build Windows Installer (.exe)

```bash
# From root folder
npm run dist:win

# Output:
# dist-electron/Safari CRM Setup 1.0.0.exe   ← installer
# dist-electron/win-unpacked/Safari CRM.exe  ← portable .exe
```

The installer creates:
- ✅ Start Menu shortcut
- ✅ Desktop icon
- ✅ Standard Windows uninstaller

---

## 🔌 Modules Included

| Module         | Status          | Features                                    |
|----------------|-----------------|---------------------------------------------|
| 🔐 Auth        | ✅ Complete     | JWT login, role-based access               |
| 📅 Dashboard   | ✅ Complete     | KPIs, recent bookings, booking form        |
| 📋 Bookings    | ✅ Complete     | Full CRUD, search, status filters          |
| 📝 Quotations  | ✅ Complete     | Create, PDF export, send                   |
| 🧾 Invoices    | ✅ Complete     | Track payments, partial/full               |
| 🚙 Fleet       | ✅ Complete     | Vehicle cards, fuel log, service           |
| 👥 HR & Staff  | ✅ Complete     | Staff table, roles, attendance             |
| 💸 Expenses    | ✅ Complete     | Add expenses, category breakdown           |
| 📊 Reports     | ✅ Complete     | Revenue chart, expense breakdown, P&L      |
| 🏕️ Reservations| 🔜 Ready       | Connect to backend                         |
| ⚖️ Tax / TRA   | 🔜 Ready       | VAT export, TRA format                     |

---

## 🗄️ Connect Real MySQL Database

The backend currently uses in-memory mock data. To connect real MySQL:

1. Open `backend/src/routes/bookings.js`
2. Replace the mock arrays with Sequelize queries:

```js
// Example: replace mock with real DB
const { Booking, Customer } = require('../models');

router.get('/', auth, async (req, res) => {
  const bookings = await Booking.findAll({
    include: [Customer],
    order: [['created_at', 'DESC']],
    limit: req.query.limit || 50,
  });
  res.json({ bookings });
});
```

3. Run the database migration:
```bash
cd backend && npm run migrate
```

---

## 📞 Tech Support

Built for: **Predictor Safari Club, Tanzania**
Version: **1.0.0**
Stack: Electron 28 · React 18 · Vite 5 · Node.js 18 · Express 4 · MySQL 8
